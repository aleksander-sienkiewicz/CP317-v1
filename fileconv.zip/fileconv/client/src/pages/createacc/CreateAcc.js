import React, {useState} from 'react'
import "./CreateAcc.css"

export default function CreateAcc() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confPass, setConfPass] = useState("")
  const handleSubmit = (e)=>{
    e.preventDefault();
    console.log(`${email}\n${password}`)
  }
  return (
    <div className="createAccount">
      <form className="loginUI" onSubmit={handleSubmit}>
        <h3>Create Account</h3>
        <input type="email" placeholder='email:' onChange={(e)=> {setEmail(e.target.value)}} value={email}></input>
        <input type="password" placeholder='password:' onChange={(e)=> {setPassword(e.target.value)}} value={password}></input>
        <input type="passworc" placeholder='confirm password:' onChange={(e)=> {setConfPass(e.target.value)}} value={confPass}></input>
        <button className='btn'>Login</button>
      </form>
    </div>
  )
}
