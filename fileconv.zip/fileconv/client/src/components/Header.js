import React from 'react'
import { Link } from 'react-router-dom'

import "./Header.css"

export default function Header() {
  return (
    <div className="header">
      <div className="headerFlex">
        <div className="titleCont">
          <Link to="/">Title Name</Link>
        </div>
        <div > 
          <Link className="btn" to="/login">Login</Link>
        </div>
      </div>
    </div>
  )
}
