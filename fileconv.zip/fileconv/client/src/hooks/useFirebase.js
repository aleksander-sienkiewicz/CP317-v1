import { useReducer, useEffect, useState } from "react"
import { db, timestamp } from "../firebase/config"
import { collection, addDoc, deleteDoc, doc, updateDoc } from 'firebase/firestore'

let initialState = {
  document: null,
  error: null,
  success: null,
  isPending: false

}

const firestoreReducer = (state, action) => {
  switch(action.type){

  }
}

export const useFirestore = (data) => {
  
}