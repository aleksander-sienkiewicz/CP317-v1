const express = require('express');
const { spawn }= require('child_process');
const {PythonShell} = require('python-shell')



const router = express.Router();


router.post("/datain", (req,res)=>{
  console.log(req.body.url)
  PythonShell.run("code.py",{
    scriptPath:"/Users/charlierocchi/Desktop/projects/owenwebsote/server/",
    args:[req.body.url]
  }, (err,res)=>{
    if (err){
      console.log(console.error())
    }
    if (res){
      console.log(res)
    }
  })

})


module.exports = router;