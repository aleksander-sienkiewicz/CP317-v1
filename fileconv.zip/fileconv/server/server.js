const express = require('express');
const bodyParser = require('body-parser');
const routesHandler = require("./routes/handler.js")

const cors = require("cors");
const app = express();


app.use(cors({
  origin:"http://localhost:3000",
  methods: ["GET", "POST"]

}))
app.use(express.json());
app.use(
  bodyParser.urlencoded({extended:false})
);

app.use('/', routesHandler)

const PORT = 4000;



app.listen(PORT, () => {console.log(`running on port ${PORT}`)})




