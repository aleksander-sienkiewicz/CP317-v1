import './App.css';
import { BrowserRouter, Switch, Route} from 'react-router-dom';

import Home from './pages/home/Home';
import Header from './components/Header';
import Login from './pages/login/Login';
import CreateAcc from './pages/createacc/CreateAcc';
function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Header/>
        <Switch>
          <Route exact path="/">
              <Home />
          </Route>
          <Route path="/login">
            <Login />
          </Route>
          <Route path="/createAccount">
            <CreateAcc/>
          </Route>
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
